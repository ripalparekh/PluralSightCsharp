﻿using System;

class Program
{
    static void Main()
    {
        var pt = new Point { X = 30, Y = 12 };
        Console.WriteLine(pt.ToString());
    }
}
