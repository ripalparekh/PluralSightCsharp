﻿var a = 30;
var b = 12;
var sum = fscalc.Calculator.Add(a, b);

System.Console.WriteLine($"{a} + {b} = {sum}");
