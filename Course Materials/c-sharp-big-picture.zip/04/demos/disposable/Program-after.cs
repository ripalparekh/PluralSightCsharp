﻿using (var w = new Widget())
{
    w.DoSomething();
}