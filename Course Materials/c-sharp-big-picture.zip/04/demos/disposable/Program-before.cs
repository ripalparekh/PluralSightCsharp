﻿var w = new Widget();

try
{
    w.DoSomething();
}
finally
{
    w.Dispose();
}