﻿var pt = new Point { X = 30, Y = 12 };
System.Console.WriteLine(pt.ToString());
