﻿var p = new Person { BirthYear = 1950 };
System.Console.WriteLine(p.Generation);
