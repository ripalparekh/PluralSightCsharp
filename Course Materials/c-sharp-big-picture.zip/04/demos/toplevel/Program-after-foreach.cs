﻿using System;

Console.WriteLine("Hello, world!");

foreach(var arg in args)
{
    Console.WriteLine(arg);
}

return 0;
